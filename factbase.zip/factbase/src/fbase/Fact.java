package fbase;

public class Fact {
  Integer ID;

  public Integer getID() {
    return ID;
  }

  public void setID(Integer iD) {
    ID = iD;
  }
  

}
