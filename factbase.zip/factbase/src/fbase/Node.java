package fbase;

public class Node extends Fact {
  
  String nodeName;

  public String getNodeName() {
    return nodeName;
  }

  public void setNodeName(String nodeName) {
    this.nodeName = nodeName;
  }

  public String getNodeNamebyID(int id_in) {
    if (id_in==ID) {
      return nodeName;
    } else {
      return null;
    }
  }
  
  public String toCommand() {
    return ("add "+nodeName);
  }

  public String toString() {
    return (nodeName);
  }

  public String toFbItem() {
    return ("n::"+ID+"::"+nodeName);
  }
}
